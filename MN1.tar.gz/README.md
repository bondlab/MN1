# Geobacter sulfurreducens MN1
Nucleotide sequence and annotation for Geobacter sulfurreducens MN1, the wild-type strain belonging to the laboratory of [Daniel Bond](http://www.thebondlab.org) at the [BioTechnology Institute](http://www.bti.umn.edu) at the University of Minnesota.
